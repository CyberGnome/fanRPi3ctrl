# OUTREDIRECT

## Description

This module will help to redirect standard output to a file

## Classes
* This module has one single class: *OutRedirect*

#### Class methods

* *OutRedirect.file(name):* - redirect output to specified file
* *OutRedirect.standard()* - redirect output to standard space (usually console)
