import sys


class OutRedirect:
    @staticmethod
    def __redirect_to_file(file_name):
        if file_name is None:
            raise ValueError("You must specify the path to the file")

        try:
            h_file = open(file_name, 'a')
        except IOError as error:
            raise ValueError("Open file error: {0}: {1}".format(
                                                        error.errno,
                                                        error.strerror))

        sys.stdout = h_file
        return h_file

    def __close_redirect_file(self):
        try:
            self.__redirect_file.close()
        except Exception:
            pass

    def file(self, name):

        h_file = self.__redirect_to_file(name)

        if self.__redirect is True:
            self.__close_redirect_file()
        else:
            self.__redirect = True

        self.__redirect_file = h_file

    def standard(self):
        if self.__redirect is True:
            sys.stdout = self.__o_stdout
            self.__close_redirect_file()
            self.__redirect = False

    def __init__(self):
        self.__redirect = False
        self.__o_stdout = sys.stdout
        self.__redirect_file = None

    def __del__(self):
        self.standard()
